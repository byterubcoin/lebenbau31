document.addEventListener( 'wpcf7submit', function( event ) {
        yaCounter25154291.reachGoal('zakaz7173');
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4122' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zamer');
        ga('send', 'event', 'zamer', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4214' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('rassrochka_zvonok');
        ga('send', 'event', 'rassrochka_zvonok', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4217' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('rassrochka');
        ga('send', 'event', 'rassrochka', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4983' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('winter_up');
        ga('send', 'event', 'winter_up', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4979' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('winter_down');
        ga('send', 'event', 'winter_down', 'Submit');   
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4199' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('vopros_zvonok');
        ga('send', 'event', 'vopros_zvonok', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4010' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('dannye_akciya');
        ga('send', 'event', 'dannye_akciya', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3991' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('dannye_konsultachiya');
        ga('send', 'event', 'dannye_konsultachiya', 'Submit');  
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4123' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zakaz_glavnaya');
        ga('send', 'event', 'zakaz_glavnaya', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4356' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zakaz');
        ga('send', 'event', 'zakaz', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3660' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zakaz_umnoe');
        ga('send', 'event', 'zakaz_umnoe', 'Submit');   
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3992' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zamer_free');
        ga('send', 'event', 'zamer_free', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4209' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zayavka_statyi');
        ga('send', 'event', 'zayavka_statyi', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4886' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('slayd');
        ga('send', 'event', 'slayd', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4054' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zakaz_cvet');
        ga('send', 'event', 'zakaz_cvet', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4355' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zvonok');
        ga('send', 'event', 'zvonok', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4144' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zakaz_kompaniya');
        ga('send', 'event', 'zakaz_kompaniya', 'Submit');   
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3993' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('dannye_akciya');
        ga('send', 'event', 'dannye_akciya', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4189' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('otziv');
        ga('send', 'event', 'otziv', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3316' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('rasjet_laminat');
        ga('send', 'event', 'rasjet_laminat', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4329' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('rachet');
        ga('send', 'event', 'rachet', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3990' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('dannye_chena_proizvoditel');
        ga('send', 'event', 'dannye_chena_proizvoditel', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4119' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('raschitat_head');
        ga('send', 'event', 'raschitat_head', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4213' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zvonok_akcii');
        ga('send', 'event', 'zvonok_akcii', 'Submit');  
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3659' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zayavka_umnie');
        ga('send', 'event', 'zayavka_umnie', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3941' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('dannye_chena_proizvoditel');
        ga('send', 'event', 'dannye_chena_proizvoditel', 'Submit'); 
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '3940' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zvonok_ustanovka');
        ga('send', 'event', 'zvonok_ustanovka', 'Submit');  
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '4116' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('konsultaciya_head');
        ga('send', 'event', 'konsultaciya_head', 'Submit');
		//alert('OK');
        console.log('12send_target');
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '5098' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zayavka_balkon');
        ga('send', 'event', 'zayavka_balkon', 'Submit');    
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '5101' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('zamer_balkon');
        ga('send', 'event', 'zamer_balkon', 'Submit');  
    }
}, false );

document.addEventListener( 'wpcf7submit', function( event ) {
    if ( '5099' == event.detail.contactFormId ) {
        yaCounter25154291.reachGoal('konsultaciya_balkon');
        ga('send', 'event', 'konsultaciya_balkon', 'Submit');   
    }
}, false );